#!/usr/bin/env python
# coding: utf-8

# # Data structure in python
There are Four Types of data Structure 
1- Tuple ,
2- Lists ,
3- Dictionary , 
4- Set 
# # 1- Tuple
Ordered collection of elements enclosed within(). 
Tuple are inmutable ..We couldn't change any elemet after creating the tuple
# In[9]:


names=("Muhammad" ,"Ahsan",109, 5.22, True , 5+3j)
names


# In[10]:


type(names)


# # Extract Indivisual elements from the tuple

# In[24]:


names


# In[25]:


names[1]


# In[26]:


names[-1]


# In[27]:


names[0:3]


# #  Modifying  a tuple

# In[29]:


# We can not Modify any tuple because Tuple is inmutable 


# In[30]:


names=("Muhammad" ,"Ahsan",109, 5.22, True , 5+3j)
names


# In[32]:


names[0]="Ali Raza" # We can  not assign any value to the tuple because tuple is immutable


# # Basic Tuple operations

# In[33]:


# 1-  Find the length of the tuple

names=("Muhammad" ,"Ahsan",109, 5.22, True , 5+3j)
names


# In[35]:


len(names)


# In[42]:


# 2-  Concatinate the two tuples  Means Cobination of two tuple

a=(1,2,3)
b=(4,5,6)
a,b 


# In[45]:


a+b # Concatinate the two tuple


# In[46]:


b+a


# In[52]:


# 3-  Repeating tuple elemets 

names=("Muhammad", "Ahsan", "Ali Raza")
names*2


# In[56]:


# 4-  Repeatin and Concatinate of the tuples

a=("Ali", "Raza")
b=("Muhammad", "Ahsan")
a*2 + b*2


# # Tuple Functions

# In[61]:


# 1-  find Minimum Value from the Tuple

number=(1,2,3,4,5,)
min(number)


# In[64]:


# 2- Find the Maximum value from the  tuple

number=(1,2,3,4,5,)
max(number)


# # 2- LISTS
Lists are Orderd collection of elements which are enclose in the [] braces
# In[66]:


# Lists are Mutable we can Add or  remove elements from the lists after making a lists


# In[68]:


lists=["Muhammad", "Ahsan", True, 12, 2.22, ]
lists


# In[69]:


type(lists)


# # Extracting Elements from the lists

# In[70]:


lists


# In[71]:


lists[1]


# In[72]:


lists[0:2]


# In[73]:


lists[0:5:2]


# # Modifying the lists

# In[74]:


names=["Muhammd", "Ahsan" ,"Ali","Raza"]
names


# In[77]:


# 1- Changing / Replacing the elements from the lists

names[3]="python is programming language"
names


# In[2]:


# 2- Add new element into the lists with the help of append Method

names=["Muhammd", "Ahsan" ,"Ali","Raza"]
names


# In[3]:


names.append("Numpy is the Libraries of Python") # add element by using append method
names


# In[4]:


names


# In[5]:


names.append(" My name is muhammad ahsan", "Python is easy to learn") # we can  add one element by "append" method
names


# In[17]:


# 3- Pop the last element from the list

my_name=["Muhammd", "Ahsan" ,"Ali","Raza"]
my_name 


# In[19]:


my_name.pop()


# In[20]:


my_name # List after pop


# In[30]:


# 4- Reverse Elements of the List

w=[1,2,3,4,5]
w


# In[31]:


w.reverse()
w


# In[39]:


# 5- Sorting the list elements

s=["b","a","c","f","d","e",]
s


# In[42]:


s.sort()


# In[43]:


s


# In[47]:


# 6- insert elemet in the spacific index 

q=[1,2,3,4,]
q


# In[48]:


q.insert(2, "Muhammad Ahsan")
q


# # List Basic Operations

# In[49]:


# 1- Concatinate the list

list1=[1,2,3,]
list2=[4,5,6,]
list1 , list2


# In[52]:


list1 + list2


# In[53]:


# 2- repeating the elements of the list

list3=["Muhammad","Ahsan"]
list3


# In[57]:


list3*3 + list1


# In[ ]:




