#!/usr/bin/env python
# coding: utf-8

# In[76]:


print( "Muhammad Ahsan  is  learning python") 


# # If Statement
 pseudo code
 
 if (Condition){
 statement to be exicuted...
 }
 else{
 statement to be Exicuted
 }
# In[3]:


a=10
b=20
a,b


# In[7]:


if a>b: # is statement is fase it could not  be exicute
    print("B is greater Then A")


# In[9]:


if a>b:
    print("A is greater Then B")
else:
    print("B is greater the A")


# In[10]:


a=10
b=20
c=30


# In[11]:


if (a>b) & (a>c):
    print("A is the Greatest")
elif (b>a) & (b>c):
    print("B is the Greatest")
else:
    print(" C is the Greatest")
    
    


# In[12]:


# use of if statement with tuple


# In[17]:


tup1=("a","b","c")


# In[21]:


if "q" in tup1:
    print("A is Present in tup1")
else:
    print("Value A is not present in tup1")


# In[23]:


# use of  if statement with List


# In[24]:


L1=["a","b","c"]


# In[25]:


if L1[1]=="b":
    L1[1]="Ahsan"


# In[26]:


L1


# In[27]:


# use of  if statement with Dictionary


# In[46]:


d1={"mango": 100, "apple": 150, "k3":200}
d1


# In[47]:


if "mango" in d1:
    print("Mango is present in d1") 


# In[49]:


d1


# In[51]:


if d1["k3"]== 200:
    d1["k3"]=d1["k3"]+100


# In[52]:


d1


# # Looping statements
Looping Statement is used to Repeat any Task multiple time
# # While loop

# In[55]:


a=1
while(a<=10):
    print(a)
    a=a+1
    


# In[1]:


# Print Table  with the help of  while loop

i=1
n=2
while(i<=10):
    print(n ,"*", i, "=", n * i)
    i=i+1


# In[2]:


# Use of While loop  into the list


# In[4]:


L2=[1,2,3,4,5]
L2


# In[9]:


i=0


# In[10]:


while i<len(L2):
    L2[i]=L2[i]+50
    i=i+1


# In[11]:


L2


# # FOR LOOP

# In[17]:


L2=["Mango","Apple", " orange"]


# In[20]:


for i in L2:
    print(i)


# In[36]:


a=  ["Black","Red", " Blue",]
b = ["laptop","chair","Mobile",]
a, b


# In[37]:


for i in a:
    for j in b:
        print(i ,j)


# # Function

# In[39]:


# Function in Real Life


# In[40]:


# Python Function


# In[43]:


# Functiio is block of code that can be  Perform Multiple Tasks


# In[44]:


def name():
    print("My name is Muhammad Ahsan")


# In[45]:


name()


# In[48]:


def add_10(x):
    return x+20


# In[49]:


add_10(50)


# In[53]:


def Odd_Even(x):
    if x%2==0:
        print(x ," is Even")
    else:
        print(x , " Is Odd")


# In[55]:


Odd_Even(21)


# # Lamda Function

# In[56]:


d=lambda x: x*x*x


# In[57]:


d(3)


# In[58]:


d(5)


# In[59]:


# lambda is used with other Function


# In[60]:


# lambda with fiter  function


# In[62]:


li=[2,3,4,54,55,67,76,53,22,]

final_list=list(filter(lambda x:(x%2!=0),li ))
     


# In[63]:


final_list


# In[64]:


# Lambda with map function


# In[66]:


l4=[1,2,3,4,5,6,7,8,9,10]
list_final=list(map(lambda x: x*2,l4))


# In[67]:


list_final


# In[69]:


#Lambda with Reduce Fuction


# In[70]:


from functools import reduce


# In[74]:


sum=(reduce(lambda x,y: x+y, l4))


# In[75]:


sum


# In[ ]:




