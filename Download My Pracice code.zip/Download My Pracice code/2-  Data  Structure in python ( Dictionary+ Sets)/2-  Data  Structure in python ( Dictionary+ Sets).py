#!/usr/bin/env python
# coding: utf-8

# # 3-Dictionary
Dictionary is an unorderd collection of key value value pair enclosed in {}  braces

Dictionary is mutable
# In[30]:


d1={"Banana": 100,"apple":200, "mango":100,"Guava": 50, "Banana": 100,}
d1


# In[3]:


type(d1)


# # Extract Keys and Values from the Dictionary

# In[4]:


# 1- extract Keys from the  dictionary

fruits={"apple":200, "mango":100,"Guava": 50, "Banana": 100,}
fruits.keys()


# In[5]:


# 2- Extract values from the Dictionary

fruits={"apple":200, "mango":100,"Guava": 50, "Banana": 100,}
fruits.values()


# # modifying the Dictionary

# In[7]:


# 1 - Add new keys and values in the existing Dictionary

fruits={"apple":200, "mango":100,"Guava": 50, "Banana": 100,}  
fruits["Pineapple"]=100
fruits


# In[10]:


# 2- Changing an existing element

fruits={"apple":200, "mango":100,"Guava": 50, "Banana": 100,}
fruits["apple"]=50
fruits


# # Dictionary Function

# In[11]:


# 1- update One  Dictionary elemet with Another Element

Fruits={"apple": 100, "Banana":50,}
New_fruits={"Orange" :70, "Mango" :60}

Fruits.update(New_fruits)
Fruits


# In[28]:


# 2 - poping an element

fruit={"apple":100, "mango" :50, "orange" :40, "mango" :50,}
fruit.pop("apple")


# In[29]:


fruit


# # 4- Sets
set is unorderd and unindexed collection of elements Enclosed in the {} braces..
# In[21]:


# Duplication is Not Allowed in the Set


# In[31]:


s1={"My Name is Muhammad Ahsan",1, False,8.10,1,} # duplicates Don't store into the sets
s1


# In[32]:


type(s1)


# # Set Operation

# In[38]:


# 1- Update one Dictionary Element with Other Element

s2={1,"ahsan", False, 2.2}
s2.add("Muhammad")
s2


# In[48]:


# 2- Update Muliple elements in to the Set

s3={1,"ahsan", False, 2.2}
s3.update(["Python is easy to learn", "Muhammad ahsan", 10, 30,])


# In[58]:


s3


# In[59]:


# 3-  Removing an element

s7={1,"ahsan", False,True, 2.2}
s7.remove(1)


# In[60]:


s7


# In[61]:


s7.remove("ahsan")


# In[62]:


s7


# # Set Function

# In[65]:


# 1- union of Two sets

set9={1,2,3}
set6={"Muhammad Ahsan", 10, 14}
set9.union(set6)


# In[68]:


# 2- Intersection of teo sets

v={13,22,31,"Muhammad Ahsan", 40,"Ali Raza" }
v


# In[69]:


v1={"Muhamad Ahsan", 13, 10, 22, 40,}
v1


# In[70]:


v.intersection(v1)


# In[ ]:




