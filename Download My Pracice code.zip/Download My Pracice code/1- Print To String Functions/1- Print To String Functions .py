#!/usr/bin/env python
# coding: utf-8

# In[1]:


print('i am learning Python')
print('Python is easy to learn')


# # 1- variables in python

# In[5]:


name= "Ali"


# In[6]:


name


# In[7]:


name='Raza'


# In[8]:


name


# In[9]:


name='Muhammad Ahsan'


# In[10]:


name


# # Data Type in python

# In[11]:


a1=10
a1


# In[12]:


type(a1)


# In[13]:


a1=3.14
a1


# In[14]:


type(a1)


# In[15]:


a1=True
a1


# In[16]:


type(a1)


# In[25]:


a1="""
Muliple Line string
My Name is 
Muhammad Ahsan
 i am Learning Python Programming language """


# In[26]:


a1


# In[27]:


type(a1)


# In[28]:


a1="Muhammad Ahsan"
a1


# In[29]:


type(a1)


# In[30]:


a1=3+4j
a1


# In[31]:


type(a1)


# # Operators In python

# In[ ]:


#Arthematic Oprator

# +,-,*,/,


# In[34]:


a=10
b=20
a,b


# In[37]:


a+b


# In[38]:


a-b


# In[39]:


a*b


# In[40]:


a/b


# In[41]:


# Relationl operator


# In[42]:


# <,>, ==, !=,


# In[44]:


a=30
b=50
a,b


# In[45]:


a<b


# In[46]:


a>b


# In[47]:


a==b


# In[48]:


a!=b


# In[49]:


#Logical Operator


# In[51]:


# & (and , When Both True, Then True) ,  | (Or, when any value True, then True)


# In[52]:


a=True
b= False


# In[53]:


a & b


# In[54]:


a & a


# In[55]:


b & a


# In[56]:


b & b


# In[57]:


a | b


# In[58]:


a | a


# In[59]:


b | a


# In[60]:


b | b 


# # Python Token

# In[61]:


#Smallest Meaningfull Components in a Program

#1- Keyword, 2- identifier, 3- Litrals, 4- Operators


# In[62]:


# Keywords are special Reserved Words


# In[63]:


True= a


# In[64]:


#Identifiers are the special words used for variables and functions & Objects


# In[65]:


student_name="Muhammad" # 1st name of variable can't be Any Digit


# In[66]:


student_name


# In[67]:


Student_name="Ahsan"


# In[68]:


Student_name


# # Python Litrals

# In[69]:


# Litrals are Constants in python That's Value can't Be change
a= "This is a Litrals"


# In[70]:


a


# In[71]:


a1=433


# In[72]:


a1


# # Python Strings

# In[73]:


# Strings are Sequences of Character , Enclosed Single, Double, & Tripple Quotes


# In[74]:


str1=' this is a string b/w single quote  '
str1


# In[75]:


str2="This is Also a String b/w Double Quote"
str2


# In[78]:


str3="""
This  is a  Multiline string b/w 
 thiple Quote, this string has Lots of Lines 
 """


# In[79]:


str3


# # Extracrac indiviual Characters from string

# In[83]:


name= "Muhammad Ahsan"
name


# In[84]:


name[0] # extract 1s character


# In[87]:


name[-1] # Extract Last Character


# In[91]:


name[9:14]


# # String Function

# In[92]:


# 1- Finiding Length
len(name)


# In[93]:


# 2- Converting string into Lower case
name.lower()


# In[94]:


# 3- Converting String into Upper case
name.upper()


# In[109]:


# 4- Replacing a substring
new_name="My name is Muhammad Ahsan"
new_name


# In[110]:


new_name.replace("is" , "are")


# In[111]:


# 5-  Number of occurance in a sub string
z="ahsan, 10, 10, 10, ahsan, "
z


# In[112]:


z.count("10")


# In[114]:


# 6-  Find the in dex of substring
b= "My name is muhammad ahsan"
b


# In[116]:


b.find("i")


# In[117]:


# 7-  Splitting a string
fruits= "I likes  apples, mangoes, bananas,and orange"
fruits


# In[118]:


fruits.split(",")


# In[119]:


intro=" my name is muhammad ahsan i am learning python, python is very easy to learn"
intro


# In[120]:


intro .split("m")


# In[ ]:




